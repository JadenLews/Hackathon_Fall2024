from django.contrib import admin
from .models import ProjectPost, Profile, Notifications
# Register your models here.
admin.site.register(ProjectPost)
admin.site.register(Profile)
admin.site.register(Notifications)

